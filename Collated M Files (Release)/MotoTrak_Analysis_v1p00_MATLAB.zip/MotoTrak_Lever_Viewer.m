function MotoTrak_Analysis_Lever_Viewer(varargin)

[files, path] = uigetfile('*.ArdyMotor','Select MotoTrak Files',...
    'multiselect','on');                                                    %Have the user pick an input *.ArdyMotor file or files.
if ~iscell(files) && files(1) == 0                                          %If no file was selected...
    return                                                                  %Exit the function.
end
cd(path);                                                                   %Change the current directory to the specified folder.
if ischar(files)                                                            %If only one file was selected...
    files = {files};                                                        %Convert the string to a cell array.
end

for f = 1:length(files)                                                     %Step through each file.
    handles = ArdyMotorFileRead(files{f});                                  %Read in the data from the *.ArdyMotor file.
    if ~isfield(handles,'trial') || isempty(handles.trial)                  %If there's no trials in this data file...
        warning('ARDYMOTOR2TEXT:NoTrials',['WARNING FROM '...
            'ARDYMOTOR2TEXT: The file "' files{f} '" has zero trials '...
            'and will be skipped.']);                                       %Show a warning.
        continue                                                            %Skip to the next file.
    end
    handles.file = files{f};                                                %Save the filename.
    handles.ir_thresh = [1023, 0];                                          %Create a matrix to hold the IR signal bounds.
    for t = 1:length(handles.trial)                                         %Step through each trial.
        handles.ir_thresh(1) = ...
            min([handles.trial(t).ir; handles.ir_thresh(1)]);               %Find the new minimum for each trial.
        handles.ir_thresh(2) = ...
            max([handles.trial(t).ir; handles.ir_thresh(2)]);               %Find the new maximum for each trial.
        s = median(double(diff(handles.trial(t).sample_times)));            %Find the median inter-sample interval for each trial.
        if s == 0                                                           %If all the inter-sample intervals are the same...
            handles.trial(t).sample_times = ...
                (10*(1:length(handles.trial(t).signal)) - 1010)';           %Use the sample times from a different trial in place of the bad times on the curren trial.
        end
    end
    if handles.ir_thresh(1) == handles.ir_thresh(2)                         %If there is no variation in the IR signal...
        handles.ir_thresh(1) = handles.ir_thresh(2) - 1;                    %Subtract one from the IR threshold minimum to calculate a dummy maximum.
    end
    handles.cur_trial = 1;                                                  %Set the current trial to 1.
    handles.num_trials = length(handles.trial);                             %Grab the number of trials.
    handles = Make_GUI(handles);                                            %Create the GUI.
    ShowTrial(handles,handles.cur_trial);                                   %Show the first trial.
    set(handles.slider,'callback',@SliderClick);                            %Set the callback for action on the slider.
    set(handles.savebutton,'callback',@SavePlot);                           %Set the callback for the save plot pushbutton.
    guidata(handles.fig,handles);                                           %Pin the handles structure to the GUI.
end


%% This function displays the force and IR traces from the selected trial.
function ShowTrial(handles,t)
pos = get(handles.fig,'position');                                          %Grab the main figure position.
area(handles.trial(t).sample_times,handles.trial(t).ir,...
    'linewidth',2,'facecolor',[1 0.5 0.5],'parent',handles.ir_axes,...
    'basevalue',handles.ir_thresh(2));                                      %Show the IR signal as an area plot.
set(handles.ir_axes,'ylim',handles.ir_thresh,'ydir','reverse',...
    'xlim',handles.trial(t).sample_times([1,end]),'xticklabel',[],...
    'ytick',[]);                                                            %Set the IR axes properties.
ylabel('IR Signal','parent',handles.ir_axes,'fontsize',0.75*pos(4),...
    'rotation',0,'verticalalignment','middle',...
    'horizontalalignment','right');                                         %Label the IR signal.
set(handles.label,'string',['Subject: ' handles.rat ', Trial ' ...
    num2str(t) '/' num2str(handles.num_trials) ', ' ...
    datestr(handles.trial(t).starttime,'HH:MM:SS, mm/dd/yy')],...
    'fontsize',0.75*pos(4));                                                %Update the trial label.
area(handles.trial(t).sample_times,handles.trial(t).signal,...
    'linewidth',2,'facecolor',[0.5 0.5 1],'parent',handles.force_axes);     %Show the force signal as an area plot.
min_max = [min(handles.trial(t).signal), max(handles.trial(t).signal)];     %Grab the minimum and maximum of the signal.
set(handles.force_axes,'xlim',handles.trial(t).sample_times([1,end]),...
    'ylim',min_max + [-0.05,0.1]*range(min_max),'fontsize',0.5*pos(4));     %Set the force axes properties.
line([0,0],min_max(2)+[0.02,0.08]*range(min_max),'color','k',...
    'parent',handles.force_axes,'linewidth',2);                             %Draw a line to show the start of the hit window.
line(1000*[1,1]*handles.trial(t).hitwin,...
    min_max(2)+[0.02,0.08]*range(min_max),'color','k',...
    'parent',handles.force_axes,'linewidth',2);                             %Draw a line to show the end of the hit window.
line([0,1000*handles.trial(t).hitwin],...
    min_max(2)+0.05*range(min_max)*[1,1],'color','k',...
    'parent',handles.force_axes,'linestyle','--','linewidth',2);            %Draw a line to show the length of the hit window.
text(500*handles.trial(t).hitwin,min_max(2)+0.05*range(min_max),...
    'Hit Window','margin',2,'edgecolor','w','backgroundcolor','w',...
    'fontsize',0.5*pos(4),'fontweight','bold',...
    'parent',handles.force_axes,'horizontalalignment','center',...
    'verticalalignment','middle');                                          %Label the hit window.
a = line([0,0],get(handles.force_axes,'ylim'),'color','k',...
    'parent',handles.force_axes,'linewidth',2,'linestyle','--');            %Draw a gray dotted line to show the start of the hit window.
uistack(a,'top');                                                        %Move the dotted line to the bottom of the stack.
a = line(1000*[1,1]*handles.trial(t).hitwin,...
    get(handles.force_axes,'ylim'),'color','k',...
    'parent',handles.force_axes,'linewidth',2,'linestyle','--');            %Draw a gray dotted line to show the end of the hit window.
uistack(a,'top');                                                        %Move the dotted line to the bottom of the stack.
ylabel('Angle (degrees)','parent',handles.force_axes,...
    'fontsize',0.75*pos(4));                                                %Label the force signal.
a = line(xlim,10*[1,1],'color',[0 0.5 0],...
    'parent',handles.force_axes,'linewidth',2,'linestyle','--');            %Draw a gray dotted line to show the end of the hit window.
uistack(a,'top');                                                        %Move the dotted line to the bottom of the stack.
a = line(xlim,10*[1,1],'color',[0 0.5 0],...
    'parent',handles.force_axes,'linewidth',2,'linestyle','--');            %Draw a gray dotted line to show the end of the hit window.
uistack(a,'top');                                                        %Move the dotted line to the bottom of the stack.
text(-900,10.1,'Press Threshold',...
    'fontsize',0.5*pos(4),...
    'color',[0 0.5 0],...
    'fontweight','bold',...
    'parent',handles.force_axes,...
    'horizontalalignment','left',...
    'verticalalignment','bottom');                                          %Label the hit window.
xlabel('Time (ms)','parent',handles.force_axes,'fontsize',0.75*pos(4));     %Label the time axis.


%% This function executes when the user interacts with the slider.
function SliderClick(hObject,~)
handles = guidata(hObject);                                                 %Grab the handles structure from the GUI.
handles.cur_trial = round(get(hObject,'value'));                            %Set the current trial to the value of the slider.
if handles.cur_trial < 1                                                    %If the current trial is less than 1...
    handles.cur_trial = 1;                                                  %Set the current trial to 1.
elseif handles.cur_trial > handles.num_trials                               %Otherwise, if the current trials is greater than the total number of trials.
    handles.cur_trial = handles.num_trials;                                 %Set the current trial to the last trial.
end
set(hObject,'value',handles.cur_trial);                                     %Update the value of the slider.
ShowTrial(handles,handles.cur_trial);                                       %Show the current trial.
guidata(hObject,handles);                                                   %Pin the handles structure back to the GUI.


%% This function executes when the user interacts with the slider.
function SavePlot(hObject,~)
handles = guidata(hObject);                                                 %Grab the handles structure from the GUI.
filename = [handles.file(1:end-10) '_TRIAL' ...
    num2str(handles.cur_trial,'%03.0f') '.png'];                            %Create a default filename for the PNG file.
[filename, path] = uiputfile('*.png','Name Image File',filename);           %Ask the user for a new filename.
if filename(1) == 0                                                         %If the user selected cancel...
    return                                                                  %Exit the function.
end
set([handles.slider,handles.savebutton],'visible','off','enable','off');    %Make the uicontrols invisible and disable them.
% fix_dotted_line_export(handles.force_axes);                                 %Fix the dotted lines in the force axes.
pos = get(handles.fig,'position');                                          %Grab the figure position.
temp = get(handles.fig,'color');                                            %Grab the starting color of the figure.
set(handles.fig,'paperpositionmode','auto',...
    'inverthardcopy','off',...
    'paperunits',get(handles.fig,'units'),...
    'papersize',pos(3:4),...
    'color','w');                                                           %Set the figure properties for printing.
set(handles.label,'backgroundcolor','w');                                   %Set the label background color to white.
drawnow;                                                                    %Immediately update the figure.
print(gcf,[path, filename],'-dpng','-r300');                                %Save the current image as a PNG file.
set([handles.slider,handles.savebutton],'visible','on','enable','on');      %Make the uicontrols visible and enabled again.
set(handles.fig,'color',temp);                                              %Reset the figure color to the original color.
set(handles.label,'backgroundcolor',temp);                                  %Set the label background color to the original color.


%% This subfunction creates the GUI.
function handles = Make_GUI(handles)
set(0,'units','centimeters');                                               %Set the system units to centimeters.
pos = get(0,'screensize');                                                  %Grab the screen size.
h = 0.8*pos(4);                                                             %Calculate the height of the figure.
w = 4*h/3;                                                                  %Scale the width of the figure to the height.
handles.fig = figure('MenuBar','none',...
    'numbertitle','off',...
    'name',['Pull Viewer: ' handles.file],...
    'units','centimeters',...
    'resize','on',...
    'ResizeFcn',@Resize,...
    'Position',[pos(3)/2-w/2, pos(4)/2-h/2, w, h]);                         %Create a figure.
handles.label =  uicontrol(handles.fig,'style','text',...
    'units','normalized',...
    'position',[0.01,0.95,0.98,0.04],...
    'string',[],...
    'fontsize',0.5*h,...
    'backgroundcolor',get(handles.fig,'color'),...
    'horizontalalignment','left',...
    'fontweight','bold');                                                   %Create a text label for showing the trial number and time.
handles.ir_axes = axes('units','normalized',...
    'position',[0.1,0.85,0.89,0.09],...
    'box','on',...
    'linewidth',2);                                                         %Create axes for showing the IR signal.
handles.force_axes = axes('units','normalized',...
    'position',[0.1,0.12,0.89,0.72],...
    'box','on',...
    'linewidth',2);                                                         %Create axes for showing the IR signal.
handles.slider = uicontrol(handles.fig,'style','slider',...
    'units','normalized',...
    'position',[0.01,0.01,0.78,0.04],...
    'value',1,...
    'min',1,...
    'max',handles.num_trials,...
    'SliderStep',[1/handles.num_trials, 0.1]);                              %Create a trial slider.
handles.savebutton = uicontrol(handles.fig,'style','pushbutton',...
    'units','normalized',...
    'position',[0.80,0.01,0.19,0.04],...
    'string','Save Plot (PNG)',...
    'fontsize',0.75*h);                                                     %Create a button for saving a plot image.


%% This function is called whenever the main figure is resized.
function Resize(hObject,~)
handles = guidata(hObject);                                                 %Grab the handles structure from the GUI.
pos = get(handles.fig,'position');                                          %Grab the main figure position.
ylabel('IR Signal','parent',handles.ir_axes,'fontsize',0.75*pos(4),...
    'rotation',0,'verticalalignment','middle',...
    'horizontalalignment','right');                                         %Label the IR signal with the new fontsize.
set([handles.label,handles.savebutton],'fontsize',0.75*pos(4));             %Update the trial label and savebutton fontsize.
objs = get(handles.force_axes,'children');                                  %Grab all children of the force axes.
objs(~strcmpi('text',get(objs,'type'))) = [];                               %Kick out all non-text objects.
set(objs,'fontsize',0.5*pos(4));                                            %Update the fontsize of all text objects.
ylabel('Angle (degrees)','parent',handles.force_axes,...
    'fontsize',0.75*pos(4));                                                %Label the angle signal.
xlabel('Time (ms)','parent',handles.force_axes,'fontsize',0.75*pos(4));     %Label the time axis.


function [data, varargout] = ArdyMotorFileRead(file)
%
%ARDYMOTORFILEREAD.m - Rennaker Neural Engineering Lab, 2011
%
%   ArdyMotorFileRead reads in the sensor recordings from motor behavioral
%   tasks controlled by an Arduino board.  The data is organized into a
%   MATLAB structure for easy analysis
%
%   data = ArdyMotorFileRead(file) reads in the behavioral record from the
%   *.ARDYMOTOR files specified by the string variable "file" into the
%   output "data" structure.
%
%   Last modified February 18, 2013, by Drew Sloan.

data = [];                                                                  %Start a data structure to receive the recordings.
fid = fopen(file,'r');                                                      %Open the file for read access.
fseek(fid,0,-1);                                                            %Rewind to the beginning of the file.

temp = dir(file);                                                           %Grab the file information.
% if temp.datenum >= 735264                                                   %If the file was created after January 29, 2013...
%     version = fread(fid,1,'int16');                                         %Read the version from the first two bytes as an signed integer.
%     if version > 0                                                          %If the integer is greater than zero...
%         version = 1;                                                        %Set the file format version to 1.
%     end
% else
    version = fread(fid,1,'int8');                                          %Read the file format version from the first byte as a signed integer.
    if (version ~= -1) || (version == -1 && daycode(temp.datenum) == 255)     %If the version isn't -1...
        if (version ~= -3)
            version = 1;                                                        %Set the file format version to 1.
        end
    end
% end

data.version = version;

if version < 0                                                              %If the file format version indicates ArdyMotor V2.0...
    
    if version == -1 || version == -3
        data.daycode = fread(fid,1,'uint16');                               %Read in the daycode.
    end
    data.booth = fread(fid,1,'uint8');                                      %Read in the booth number.
    N = fread(fid,1,'uint8');                                               %Read in the number of characters in the rat's name.
    data.rat = fread(fid,N,'*char')';                                       %Read in the characters of the rat's name.
    data.position = fread(fid,1,'float32');                                 %Read in the device position, in centimeters.
    N = fread(fid,1,'uint8');                                               %Read in the number of characters in the stage description.
    data.stage = fread(fid,N,'*char')';                                     %Read in the characters of the stage description.
    N = fread(fid,1,'uint8');                                               %Read in the number of characters in the device name.
    data.device = fread(fid,N,'*char')';                                    %Read in the characters of the device name.
    fileinfo = dir(file);                                                   %Grab the input file information.
    
    data.cal = [1,0];                                                       %Assume by default that no calibration conversion was applied.
    if fileinfo.datenum < 735088                                            %If this file was written between 8/3/2012 and 8/6/2012
        data.device = 'Wheel';                                              %Set the device name to 'Wheel'.
        data.cal(1) = 0.5;                                                  %Set the degrees/tick calibration constant to 0.5.
    end
      
    if (version == -3)
        if any(strcmpi(data.device,{'pull', 'knob', 'lever'}))
            data.cal(:) = fread(fid,2,'float32');
        elseif any(strcmpi(data.device,{'wheel'}))
            data.cal(1) = fread(fid,1,'float32');                              
        end
    else      
        if any(strcmpi(data.device,{'pull'}))                                   %If the device was a pull...
            data.cal(:) = fread(fid,2,'float32');                               %Read in the grams/tick and baseline grams calibration coefficients.
        elseif any(strcmpi(data.device,{'wheel','knob'})) && ...
                fileinfo.datenum > 735088                                       %If the device was a wheel or a knob...
            data.cal(1) = fread(fid,1,'float32');                               %Read in the degrees/tick calibration coefficient.
        end
    end
    
    N = fread(fid,1,'uint8');                                               %Read in the number of characters in the constraint description.
    data.constraint = fread(fid,N,'*char')';                                %Read in the characters of the constraint description.
    N = fread(fid,1,'uint8');                                               %Read in the number of characters in the threshold type description.
    data.threshtype = fread(fid,N,'*char')';                                %Read in the characters of the threshold type  description.
    if version == -1 || version == -3                                       %If the file format version is -1...
        data.pre_trial_sampling_dur = 1000;                                 %Indicate 1000 milliseconds of pre-trial sampling.
    else                                                                    %Otherwise, for later versions...
        data.pre_trial_sampling_dur = fread(fid,1,'float32');               %Read in the pre-trial sampling duration (in milliseconds).
    end
    data.pauses = [];                                                       %Create a field in the data structure to hold pause times.
    data.manual_feeds = [];                                                 %Create a field in the data structure to hold manual feed times.
    while ~feof(fid)                                                        %Loop until the end of the file.
        trial = fread(fid,1,'uint32');                                      %Read in the trial number.
        if isempty(trial)                                                   %If no trial number was read...
            continue                                                        %Skip execution of the rest of the loop.
        end
        starttime = fread(fid,1,'float64');                                 %Read in the trial start time.
        outcome = fread(fid,1,'uint8');                                     %Read in the trial outcome.
        if outcome == 'P'                                                   %If the outcome was a pause...
            temp = fread(fid,1,'float64');                                  %Read in the end time of the pause.
            data.pauses(end+1,1:2) = [starttime, temp];                     %Save the start and end time of the pause.
        elseif outcome == 'F'                                               %If the outcome was a manual feeding.
            data.manual_feeds(end+1,1) = starttime;                         %Save the timing of the manual feeding.
        else                                                                %Otherwise, if the outcome was a hit or a miss...
            if fileinfo.datenum < 735122.5980                               %If a file was created before 9/10/2012...
                fseek(fid,-1,'cof');                                        %Rewind the file one byte.
            end

            data.trial(trial).starttime = starttime;                        %Save the trial start time.
            data.trial(trial).hitwin = fread(fid,1,'float32');              %Read in the hit window.
            data.trial(trial).init = fread(fid,1,'float32');                %Read in the initiation threshold.
            data.trial(trial).thresh = fread(fid,1,'float32');              %Read in the hit threshold.
            data.trial(trial).hittime = [];                                 %List no hit times for this trial by default.
            N = fread(fid,1,'uint8');                                       %Read in the number of hits for this trial.
            data.trial(trial).hittime = fread(fid,N,'float64');             %Read in the hit times for this trial.
            if fileinfo.datenum <  735122.5980                              %If a file was created before 9/10/2012...
                if N > 1                                                    %If there was at least one hit time...
                    outcome = 'H';                                          %Label the trial as a hit.
                else                                                        %Otherwise...
                    outcome = 'M';                                          %Label the trial as a miss.
                end
            end
            data.trial(trial).outcome = outcome;                            %Save the trial outcome.
            N = fread(fid,1,'uint8');                                       %Read in the number of VNS events for this trial.
            data.trial(trial).vnstime = fread(fid,N,'float64');             %Read in the VNS event times for this trial.
            buffsize = fread(fid,1,'uint32');                               %Read in the number of samples for this trial.
            data.trial(trial).sample_times = ...
                fread(fid,buffsize,'uint16');                               %Read in the sample times, in milliseconds.
            data.trial(trial).signal = fread(fid,buffsize,'float32');       %Read in the device signal.
            data.trial(trial).ir = fread(fid,buffsize,'int16');             %Read in the IR signal.
            if all(data.trial(trial).sample_times == 0)                     %If all of the sample times equal zero...
                if trial ~= 1                                               %If this isn't the first trial...
                    data.trial(trial).sample_times = ...
                        data.trial(trial-1).sample_times;                   %Use the previous trial's sample times.
                else                                                        %Otherwise...
                    data.trial(trial).sample_times = ...
                        int16(10*(1:length(data.trial(trial).signal)) - ...
                        data.pre_trial_sampling_dur)';                      %Subtract the pre-trial sampling duration from the sample times.
                end
            else                                                            %Otherwise...
                data.trial(trial).sample_times = ...
                    int16(data.trial(trial).sample_times) - ...
                    data.pre_trial_sampling_dur;                            %Subtract the pre-trial sampling duration from the sample times.
            end
        end
    end
    if version < -1 && isfield(data,'trial') && ...
            isfield(data.trial,'starttime')                                 %If the file format version is newer than version -1 and the daycode function exists...
        data.daycode = daycode(data.trial(1).starttime);                    %Find the daycode for this file.
    end
elseif version == 1                                                         %If the file format version is 1...
    fseek(fid,0,-1);                                                        %Rewind to the beginning of the file.
    data.version = 1;                                                       %Version of the struct
    data.daycode = fread(fid,1,'uint16');                                   %DayCode.
    data.booth = fread(fid,1,'uint8');                                      %Booth number.
    N = fread(fid,1,'uint8');                                               %Number of characters in the rat's name.
    data.rat = fread(fid,N,'*char')';                                       %Characters of the rat's name.
    data.position = fread(fid,1,'uint8');                                   %Position of the input device (0-3 inches).
    data.responsewindow = fread(fid,1,'uint8');                             %Response window.
    data.stage(1) = fread(fid,1,'uchar');                                   %First character of the stage title stage number.
    temp = fread(fid,1,'uchar');                                            %Read in the next character.
    while temp(end) ~= data.stage(1)                                        %Loop until we get to the first letter of the device description.
        temp = [temp, fread(fid,1,'uchar')];                                %Read in the next character.
    end
    data.stage = char(horzcat(data.stage,temp(1:end-1)));                   %Concatenate the stage name together.
    if data.stage(1) == 'P'                                                 %If the stage is a pull stage...
        data.device = horzcat(temp(end),fread(fid,3,'*char')');             %Read in the selected device (Pull).
    else                                                                    %Otherwise, if the stage is a lever or wheel stage...
        data.device = horzcat(temp(end),fread(fid,4,'*char')');             %Read in the selected device (Lever or Wheel).
    end
    data.bin = fread(fid,1,'uint8');                                        %Bin Size.
    numparams = fread(fid,1,'uint8');                                       %Number of stimulus parameters.
    for i = 1:numparams                                                     %Step through each stimulus parameter.
        N = fread(fid,1,'uint16');                                          %Number of characters in a parameter name.
        data.param(i).name = fread(fid,N,'*char')';                         %Parameter name.
    end
    trial = 0;                                                              %Start a trial counter.
    while ~feof(fid)                                                        %Loop until the end of the file.
        trial=trial+1;                                                      %Increment the trial counter.
        try                                                                 %Try to read in a trial, abort if the trial is corrupted.
            data.trial(trial).threshold = fread(fid,1,'uint16');            %Read Threshold.
            data.trial(trial).starttime = fread(fid,1,'float64');           %Read trial start time.
            data.trial(trial).hittime = fread(fid,1,'float64');             %Read hit/reward time.
            data.trial(trial).outcome = fread(fid,1,'float64');             %Read Trial Outcome.
            for i = 1:3                                                     %Step through the three IR inputs.
                numIR = fread(fid,1,'uint32');                              %Read the number of breaks on the IR input.
                data.trial(trial).IR1(i).times = ...
                    fread(fid,numIR,'float64');                             %Read in the timestamp for the IR break.
            end
            numbins = fread(fid,1,'uint32');                                %Read in the number of signal datapoints.
            data.trial(trial).signal = fread(fid,numbins,'float64');        %Read in the sensory signal.
        catch ME                                                            %If an error occurs...
            lastwarn(['ARDYMOTORFILEREAD: ' ME.message],...
                ['ARDYMOTORFILEREAD:' ME.identifier]);                      %Save the warning ID.
        end
    end
    if isempty(data.trial(end).starttime)                                   %If the last trial had no data...
        data.trial(end) =[];                                                %Remove the empty trial.
    end
end
if isfield(data,'trial') && ~isempty(data.trial)                            %If there's at least one trial...
    data.daycode = fix(data.trial(1).starttime);                            %Set the daycode to the fixed first trial timestamp.
end
fclose(fid);                                                                %Close the input file.
varargout{1} = version;                                                     %Output the format version number if the user asked for it.


%% This subfunction returns the daycode (1-365) for a given date.
function d = daycode(date)
date = datevec(date);                                                       %Convert the serial date number to a date vector.
year = date(1);                                                             %Pull the year out of the date vector.
month = date(2);                                                            %Pull out the month.
day = date(3);                                                              %Pull out the day.
if year/4 == fix(year/4);                                                   %If the year is a leap year...
    numDays = [31 29 31 30 31 30 31 31 30 31 30 31];                        %Include 29 days in February.
else                                                                        %Otherwise...
	numDays = [31 28 31 30 31 30 31 31 30 31 30 31];                        %Include 28 days in February.
end
date = sum(numDays(1:(month-1)));                                           %Sum the days in the preceding months...
d = date + day;                                                             %...and add the day of the specified month.


function y = range(x,dim)
%RANGE  Sample range.
%   Y = RANGE(X) returns the range of the values in X.  For a vector input,
%   Y is the difference between the maximum and minimum values.  For a
%   matrix input, Y is a vector containing the range for each column.  For
%   N-D arrays, RANGE operates along the first non-singleton dimension.
%
%   RANGE treats NaNs as missing values, and ignores them.
%
%   Y = RANGE(X,DIM) operates along the dimension DIM.
%
%   See also IQR, MAD, MAX, MIN, STD.

%   Copyright 1993-2004 The MathWorks, Inc.
%   $Revision: 1.1.8.1 $  $Date: 2010/03/16 00:17:06 $

if nargin < 2
    y = max(x) - min(x);
else
    y = max(x,[],dim) - min(x,[],dim);
end